export type PaymentProviderId = 'PAYSTACK' | 'SQUAD' | 'MONNIFY';

export interface GatewayCapabilities {
  supportsDedicatedVirtualAccounts: boolean;
  supportsDynamicVirtualAccounts: boolean;
  supportsCheckout: boolean;
  supportsBankTransfer: boolean;
  supportsRefunds: boolean;
  supportsPayouts: boolean;
}

export interface PaymentInitParams {
  reference: string;
  amount: number; // in NGN
  email: string;
  name?: string;
  phone?: string;
  callbackUrl?: string;
  metadata?: Record<string, any>;
  channels?: string[];
}

export interface PaymentInitResult {
  success: boolean;
  reference: string;
  provider: PaymentProviderId;
  authorizationUrl?: string;
  checkoutUrl?: string;
  accessCode?: string;
  publicKey?: string;
  providerReference?: string;
  message?: string;
  raw?: any;
}

export interface PaymentVerifyResult {
  success: boolean;
  verified: boolean;
  provider: PaymentProviderId;
  reference: string;
  providerTransactionId?: string;
  amount: number; // in NGN
  fee?: number; // in NGN
  netAmount?: number; // in NGN
  currency: string;
  channel?: string;
  paidAt?: string;
  customerEmail?: string;
  status: 'SUCCESS' | 'FAILED' | 'PENDING' | 'REVERSED';
  message: string;
  raw?: any;
}

export interface CustomerVirtualAccountParams {
  userId: string;
  email: string;
  firstName: string;
  lastName: string;
  phone: string;
  bvn?: string;
  preferredBank?: string;
}

export interface VirtualAccountResult {
  success: boolean;
  supported: boolean;
  provider: PaymentProviderId;
  accountNumber?: string;
  accountName?: string;
  bankName?: string;
  bankCode?: string;
  customerCode?: string;
  reference?: string;
  status: 'ACTIVE' | 'PENDING' | 'FAILED' | 'UNAVAILABLE';
  message?: string;
  raw?: any;
}

export interface WebhookProcessResult {
  handled: boolean;
  verified: boolean;
  eventType: string;
  reference?: string;
  providerTransactionId?: string;
  amount?: number; // in NGN
  fee?: number;
  customerEmail?: string;
  status?: 'SUCCESS' | 'FAILED' | 'PENDING' | 'REVERSED' | 'IGNORED';
  isVirtualAccountDeposit?: boolean;
  virtualAccountNumber?: string;
  message: string;
  raw?: any;
}

export interface TransactionStatusResult {
  provider: PaymentProviderId;
  reference: string;
  providerTransactionId?: string;
  status: 'SUCCESS' | 'FAILED' | 'PENDING' | 'UNKNOWN';
  amount?: number;
  message: string;
  raw?: any;
}

export interface RefundResult {
  success: boolean;
  refundId?: string;
  reference: string;
  amount?: number;
  status: 'PENDING' | 'PROCESSED' | 'FAILED';
  message: string;
  raw?: any;
}

export interface ProviderBalanceResult {
  provider: PaymentProviderId;
  availableBalance: number;
  ledgerBalance?: number;
  currency: string;
  raw?: any;
}

export interface TestConnectionResult {
  success: boolean;
  provider: PaymentProviderId;
  mode: 'test' | 'live';
  message: string;
  balance?: ProviderBalanceResult;
  details?: Record<string, any>;
}

export interface PaymentGateway {
  readonly name: string;
  readonly providerId: PaymentProviderId;
  readonly capabilities: GatewayCapabilities;

  initializePayment(params: PaymentInitParams): Promise<PaymentInitResult>;
  verifyPayment(reference: string, options?: any): Promise<PaymentVerifyResult>;
  createCustomerVirtualAccount(customer: CustomerVirtualAccountParams): Promise<VirtualAccountResult>;
  getVirtualAccount(customer: CustomerVirtualAccountParams): Promise<VirtualAccountResult>;
  getCustomerVirtualAccount?(customer: CustomerVirtualAccountParams): Promise<VirtualAccountResult>;
  handleWebhook(payload: any, headers?: Record<string, string | string[]>): Promise<WebhookProcessResult>;
  getTransactionStatus(reference: string): Promise<TransactionStatusResult>;
  refundPayment?(reference: string, amount?: number): Promise<RefundResult>;
  getProviderBalance?(): Promise<ProviderBalanceResult>;
  testConnection(): Promise<TestConnectionResult>;
}
